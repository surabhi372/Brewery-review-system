<?php
include 'database.php';


$city = isset($_GET['city']) ? $_GET['city'] : 'DefaultCity';


$query = "SELECT id, name, city, brewery_type, phone, postal_code, website_url FROM info WHERE city = '$city'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Database query error: " . mysqli_error($conn));
}


if (isset($_POST['submit_review'])) {
    $brewery_id = $_POST['brewery_id'];
    $review_text = $_POST['review_text'];

    
    $insert_review_query = "INSERT INTO reviews (brewery_id, review_text) VALUES ($brewery_id, '$review_text')";

    if (mysqli_query($conn, $insert_review_query)) {
        echo "Review submitted successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Brewery Information - <?php echo $city; ?></title>
</head>
<body>
    <h2>Brewery Information for <?php echo $city; ?></h2>

    <table class="table table-bordered table-hover">
        <tr style="background-color: #6db6b9e6;">
            <th>Name</th>
            <th>City</th>
            <th>Brewery Type</th>
            <th>Phone</th>
            <th>Postal Code</th>
            <th>Website URL</th>
            <th>Rate Brewery</th>
            <th>Submit Review</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . $row['city'] . "</td>";
            echo "<td>" . $row['brewery_type'] . "</td>";
            echo "<td>" . $row['phone'] . "</td>";
            echo "<td>" . $row['postal_code'] . "</td>";
            echo "<td><a href='" . $row['website_url'] . "'>" . $row['website_url'] . "</a></td>";
            echo "<td>";
            echo "<form method='post' action='process_rating.php'>";
            echo "<input type='hidden' name='brewery_id' value='" . $row['id'] . "'>";
            echo "<label for='rating'>Rate:</label>";
            echo "<select name='rating' id='rating'>";
            echo "<option value='1'>1 - Poor</option>";
            echo "<option value='2'>2 - Fair</option>";
            echo "<option value='3'>3 - Good</option>";
            echo "<option value='4'>4 - Very Good</option>";
            echo "<option value='5'>5 - Excellent</option>";
            echo "</select>";
            echo "<input type='submit' value='Submit Rating'>";
            echo "</form>";
            echo "</td>";
            echo "<td>";
            echo "<form method='post' action='process_reviews.php'>";
            echo "<input type='hidden' name='brewery_id' value='" . $row['id'] . "'>";
            echo "<label for='review_text'>Review:</label>";
            echo "<textarea name='review_text'></textarea>";
            echo "<input type='submit' name='submit_review' value='Submit Review'>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>