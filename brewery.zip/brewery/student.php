<?php
include 'database.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Brewery Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style type="text/css">
        .srch {
            padding-left: 860px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }
        
        th {
            background-color: #6db6b9e6;
        }

        
    </style>
</head>
<body>

<!--__________________________search bar________________________-->
<div class="container">
    <div class="srch">
        <form class="navbar-form" method="post" name="form1">
            <input class="form-control" type="text" name="search" placeholder="Search data.." required="">
            <button class="btn btn-dark btn-sm" name="submit">Search</button>
        </form>
    </div>

    <h2>Brewery Information</h2>

    <?php
    if (isset($_POST['submit'])) {
        $search = $_POST['search'];
        $query = "SELECT name, city, brewery_type, phone, postal_code, website_url,address_1 FROM `info` WHERE city LIKE '%$search%' OR brewery_type LIKE '%$search%'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 0) {
            echo "Sorry! No data found. Try searching again.";
        } else {
            echo "<table class='table table-bordered table-hover' >";
            echo "<tr style='background-color: #6db6b9e6;'>";
           
            echo "<th>name</th>";
            echo "<th>city</th>";
            echo "<th>brewery_type</th>";
            echo "<th>phone</th>";
            echo "<th>postal_code</th>";
            echo "<th>website_url</th>";
            echo "<th>address_1</th>";
            echo "</tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td><a href='information.php?city=" . $row['city'] . "'>" . $row['name'] . "</a></td>";
                echo "<td>" . $row['city'] . "</td>";
                
                echo "<td>" . $row['brewery_type'] . "</td>";
                echo "<td>" . $row['phone'] . "</td>";
                echo "<td>" . $row['postal_code'] . "</td>";
                echo "<td>" . $row['website_url'] . "</td>";
                echo "<td>" . $row['address_1'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
    ?>
</div>
</body>
</html>