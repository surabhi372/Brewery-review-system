<?php
	$conn = mysqli_connect('localhost', 'root', '', 'brewery') or die(mysqli_error());
	
	if(!$conn){
		die("Error: Failed to connect to database");
	}
?>