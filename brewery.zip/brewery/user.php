<?php
include 'database.php'

?>
<!DOCTYPE html>
<html>
<head>
	<title>Brewery Information</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Search data</title>
	<style type="text/css">
		

	</style>
</head>
<body>

<div class="container my-5">
	<form method="post">
			
				<input type="text" placeholder="Search data" name="search">
                <button class="btn btn-dark btn-sm" name="submit">Search</button>
</form>
<div class="container my-5">
    <table class="table">
        <?php
        if(isset($_POST['submit'])){
            $search=$_POST['search'];
            $sql="Select * from 'info' where city like'%$search%' or name like'%$search%' or brewery_type like'%$search%'";
            $result=mysqli_query($conn,$sql);
            if($result){
                if(mysqli_num_rows($result)>0)
                {
                    echo '<thead>
                    <tr>
                    <th>name</th>
                    <th>brewery_type</th>
                    <th>city</th>
                    </tr>
                    ';

                
                while($row=mysqli_fetch_assoc($result)){
                echo '<tbody>
            <tr>
            <td>'.$row['name'].'</td>
               <td>'.$row['brewery_type'].'</td>
               <td>'.$row['city'].'</td>
        
        
        </tr>
    </tbody>';
                }
}else{
    echo '<h2 class=:text-danger >Data not found</h2>';
}
               }
            }
            

               ?>
               

</table>
</div>


	