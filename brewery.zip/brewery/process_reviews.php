<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $brewery_id = $_POST['brewery_id'];
    $user_id = 1;  
    $review_text = $_POST['review_text'];
    $created_at = date('Y-m-d H:i:s'); 

    $reviewQuery = "INSERT INTO reviews (id, user_id, review_text, created_at) 
              VALUES ('$brewery_id', '$user_id', '$review_text', '$created_at')";
    $reviewResult = mysqli_query($conn, $reviewQuery);

    if ($reviewResult) {
       
        echo "Review submitted successfully.";
    } else {
        
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request method.";
}
?>






