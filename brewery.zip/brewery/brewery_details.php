<form method="post" action="process_rating.php">
    <input type="hidden" name="brewery_id" value="<?php echo $breweryId; ?>">
    <label for="rating">Rate this brewery:</label>
    <select name="rating" id="rating">
        <option value="1">1 - Poor</option>
        <option value="2">2 - Fair</option>
        <option value="3">3 - Good</option>
        <option value="4">4 - Very Good</option>
        <option value="5">5 - Excellent</option>
    </select>
    <input type="submit" value="Submit Rating">
</form>