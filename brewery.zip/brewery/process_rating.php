<?php
include 'database.php';

if (isset($_POST['brewery_id']) && isset($_POST['rating'])) {
    $breweryId = $_POST['brewery_id'];
    $rating = $_POST['rating'];

    // Perform validation on $rating if needed

    // Insert the rating into the database
    $insertRating = "INSERT INTO brewery_ratings (brewery_id, rating) VALUES ('$breweryId', '$rating')";
    if (mysqli_query($conn, $insertRating)) {
        echo "Rating submitted successfully.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}